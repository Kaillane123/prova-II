/*
Aplicando a técnica de destructuring, crie uma função chamada 'detalharEndereco' que 
receba um objeto 'endereco' contendo propriedades como 'rua', 'cidade' e 'CEP'. A 
função deve desestruturar essas informações do objeto e retornar uma string formatada 
com esses detalhes. Por exemplo, se o objeto for {rua: 'Rua das Flores', cidade: 'Porto 
Alegre', CEP: '90000-000'}, a função deve retornar a string: 'Rua: Rua das Flores, Cidade: 
Porto Alegre, CEP: 90000-000'."
*/

function detalharEndereco(event) {
    const rua = event.rua;
    const cidade = event.cidade;
    const CEP = event.CEP

    console.log(rua, cidade,CEP);
  }
